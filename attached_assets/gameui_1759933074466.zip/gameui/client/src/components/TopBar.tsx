export default function TopBar() {
  return null;
}